var data;
function getElementByXpath(path) {
  return document.evaluate(path, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
}

function createGraph(){
	var mainBody=document.getElementsByClassName("maintable")[0].firstElementChild
	graphRow=document.createElement("tr");
	graphCol=document.createElement("td");
	graphCol.setAttribute("class", "content");
	graphCol.setAttribute("style","height: 430px")
	graphContainer = document.createElement("div");
	graphContainer.setAttribute("class", "container");
	graphCol.appendChild(graphContainer);
	graphRow.appendChild(graphCol)
	mainBody.appendChild(graphRow);
}
function getData(){
	console.log(getElementByXpath('//*[@id="ember382"]/div[2]/div/div[3]/div[1]').innerText);
}
	getData();
	createGraph();

//*[@id="ember382"]/div[2]/div/div[3]