 plugin to introduce time complexity feature in code chef ide 

 the techneque is dynamic analysis of input data and time and fit a curve to the data